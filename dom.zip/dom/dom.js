// Reference xthe sid with getElementById

const getMusic = document.querySelectorAll("#bad");

getMusic.forEach(function(artist){
    console.log(artist);
})

console.log(getMusic);